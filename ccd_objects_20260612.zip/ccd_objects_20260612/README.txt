CCD Platform — Object Bundle
Generated: 2026-06-12 14:53
Net Groups : NG-20260612_v6
Net Objects: SO-20260612_v6

To view:
  macOS/Linux — double-click object-viewer-web-service.sh
             OR run: ./object-viewer-web-service.sh
  Then open:  http://127.0.0.1:8080/edl_catalog.html

Requirements: Python 3 (included with macOS and most Linux distros)
